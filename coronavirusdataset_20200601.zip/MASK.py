# %%
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
# import seaborn as sns
from datetime import datetime
from dateutil.relativedelta import relativedelta
mpl.rc('font', family = 'Malgun Gothic')


# %%
ipynb-py-convert MASK.ipynb MASK.py

# %%
corona_conf = pd.read_csv('time.csv') # 일별 확진자 누적데이터.csv
corona_conf
# 사회적 거리두기 2020-03-22

# %%
policy_date = pd.read_csv('policy.csv') # 정책별 시행/종료 날짜데이터.csv
policy_date

# %%
# policy_start =  corona['date'] == "2020-03-22"
corona_conf.info()

# %%
policy_date.info()

# %%
# 사회적 거리두기 정책 시행 날짜
MASK_date = policy_date[policy_date['detail'] == "5-day Rotation System"]
MASK_applydate = MASK_date.iloc[0].start_date
MASK_applydate

# %%
# 시행날짜 타입 변경(date) => 1달전, 후 날짜 추출
MASK_applydate_date = datetime.strptime(MASK_applydate,"%Y-%m-%d") # 시행날짜 타입 변경
MASK_be_applydate_date = MASK_applydate_date - relativedelta(months= 1) # 30일 전
MASK_aft_applydate_date = MASK_applydate_date + relativedelta(months= 1) # 30일 후
MASK_be_applydate_date,MASK_aft_applydate_date
MASK_be_applydate = str(MASK_be_applydate_date) # 사회적 거리두기 정책 시행 30 일전 날짜
MASK_aft_applydate = str(MASK_aft_applydate_date) # 사회적 거리두기 정책 시행 30 일후 날짜

# %%
# 정책 시행일 30일 전 코로나 누적 확진자 수
MASK_be_applydate = MASK_be_applydate[:10]
MASK_policy_be_conf = corona_conf[corona_conf['date'] == MASK_be_applydate]
MASK_policy_be_applyconf = MASK_policy_be_conf.iloc[0].confirmed
MASK_policy_be_applyconf

# %%
# 정책 시행일 코로나 누적 확진자 수
MASK_policy_conf = corona_conf[corona_conf['date'] == MASK_applydate]
MASK_policy_applyconf = MASK_policy_conf.iloc[0].confirmed
MASK_policy_applyconf

# %%
# 정책 시행일 30일 후 코로나 누적 확진자 수
MASK_aft_applydate = MASK_aft_applydate[:10]
MASK_policy_aft_conf = corona_conf[corona_conf['date'] == MASK_aft_applydate]
MASK_policy_aft_applyconf = MASK_policy_aft_conf.iloc[0].confirmed
MASK_policy_aft_applyconf

# %%
# 시행일 전 30일 사이에 확진자 수 =
# 정책 시행일 누적 확진자 수 - 30일 전 누적 확진자 수 
MASK_before_conf = MASK_policy_applyconf - MASK_policy_be_applyconf
MASK_before_conf

# %%
# 시행일 후 30일 사이에 확진자 수 =
# 정책 시행일 30일 후 누적 확진자 수 - 정책 시행일 누적 확진자 수
MASK_after_conf = MASK_policy_aft_applyconf - MASK_policy_applyconf
MASK_after_conf

# %%
# 시행 전,후 차이량
MASK_change_rate = MASK_before_conf - MASK_after_conf

# %%
MASK_confirmed = [MASK_before_conf,MASK_after_conf,MASK_change_rate]
MASK_index = np.arange(len(confirmed))
MASK_conf_name = ['시행전','시행후','변화량']
MASK_colors = ['indianred','royalblue','darkorchid']

# %%
plt.bar(MASK_index,MASK_confirmed, color = MASK_colors)
plt.title("사회적 거리두기 정책 시행 전,후 확진자 수")
plt.ylabel("확진자")
plt.xticks(MASK_index,MASK_conf_name)

for i,v in enumerate(MASK_index):
    plt.text(v, MASK_confirmed[i], MASK_confirmed[i],
            fontsize = 10,
            horizontalalignment='center',
            verticalalignment='bottom')
plt.show()

# %%


# %%


# %%
